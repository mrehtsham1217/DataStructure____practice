#include <iostream>
using namespace std;
class Patient
{
    private:

    int patientID;
    string patientName;
    int PatientAge;
    string patientDisease;

public:
    Patient() {}
    Patient(int patientID, string patientName, int PatientAge, string patientDisease)
    {
        this->patientID = patientID;
        this->patientName = patientName;
        this->PatientAge = PatientAge;
        this->patientDisease = patientDisease;
    }

    void SetPaitentId(int id)
    {
         this->patientID = id;
    }

    void SetPaitentName(string name)
    {
         this->patientName = name;
    }

    void SetPaitentAge(int age)
    {
        this->PatientAge = age;
    }

     void SetPaitentDisease(string disease)
    {
       this->patientDisease = disease;
    }

     int GetPaitentId()
    {
        return this->patientID;
    }

    string GetPaitentName()
    {
        return this->patientName;
    }

    int GetPaitentAge()
    {
       return this->PatientAge;
    }

     string GetPaitentDisease()
    {
       return this->patientDisease;
    }

};