#include <iostream>
using namespace std;
class Doctors
{
    private:

    int doctorID;
    string doctorName;
    string specialization;

    public:
    Doctors() {}
    Doctors(int doctorID, string doctorName, string specialization)
    {
        this->doctorID = doctorID;
        this->doctorName = doctorName;
        this->specialization = specialization;
    }

    void SetDoctorId(int id)
    {
        this->doctorID  =  id;
    }

    void SetDoctorName(string name)
    {
     this->doctorName = name;
    }

    void SetSpecialization(string specialization)
    {
         this->specialization = specialization;
    }

    int GetDoctorId()
    {
       return this->doctorID;
    }

    string GetDoctorName()
    {
        return this->doctorName;
    }

    string GetSpecialization()
    {
        return this->specialization;
    }
};